# Tạo mảng 2 chiều với giá trị mặc định là 1
import numpy as np
arr = np.ones((5, 4))
print(arr)