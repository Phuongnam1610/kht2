from adb import *
import numpy as np
pkgame="com.tepaylink.kiemhieptinh2mobile"
pkgame2="com.tepaylink.kiemhieptinh2mobile/org.cocos2dx.cpp.AppActivity"

class toolLQ():
    def __init__(self,udid,riotid="a"):
        self.udid=udid
        self.listtk=""
        self.riotid=riotid.split("#")
        self.arr = np.ones((5, 4))



    def loadgame(self):
        closeGame(self.udid,pkgame)
        time.sleep(1)
        moGame(self.udid,pkgame2)
        time.sleep(8)
    
    def dungdi(self):
        for i in range(5):
            # click(self.udid, 856,110 ,"map")
            # if (findFor(self.udid, 5, "dichuyen.png", 0)!= 0):
                # for i in range(50):
                    sc1=screen_capture(self.udid)[41:52,829:880]
                    time.sleep(4)
                    sc2=screen_capture(self.udid)[18:65,802:896]
                    if(find3(sc2,sc1,threshold=0.99)!=0):
                        print('da ket thuc di chuyen')
                        time.sleep(1)
                        return True
            # else:
                # findFor(self.udid, 1, "nutx.png", 1,threshold=0.85)    

        return False
                    
                    
                
    
    def phu(self):
        if (findFor(self.udid, 1, "dailyphu.png",0,threshold=0.75 )!= 0):
                return True
        else:
            for i in range(5):
                if(findFor(self.udid, 1, "phu.png", 1)!= 0):
                    time.sleep(10)
                    if (findFor(self.udid, 5, "dailyphu.png", 0,threshold=0.8)!= 0):
                        return True
                else:
                    click(self.udid,916 ,384 )
                    time.sleep(1)
        return False
    
    def chuduocdiem(self):
        for i in range(5):
            click(self.udid, 856,110 ,"map")
            if (findFor(self.udid, 5, "dichuyen.png", 0)!= 0):
                click(self.udid, 563, 301,"chuduocdiem")
                self.dungdi()
                a=findFor(self.udid, 50, "laco.png", 0,threshold=0.85)
                if (a!= 0):
                    for i in range(3):
                        click(self.udid, int(a[0][0])-133,int(a[0][1]) +72)
                        time.sleep(1)
                        if (findFor(self.udid, 1, "hanhtrang.png", 0)!= 0):
                            return True
                    
                    return False
            else:
                findFor(self.udid, 1, "nutx.png", 1,threshold=0.85)    
    
            
                    
    
    def update_value(self,o):
        vthang = (o - 1) // 5 + 1
        vtcot = (o - 1) % 5 + 1
        x=int(vtcot*54.8-(54.8/2))
        y=int(vthang*52.75-(52.75/2))
        return (x+492,y+149)
    def locdo(self):
        # y=False
        # for i in range(5):
        #     click(self.udid, 608, 515,"hanh trang")
        #     time.sleep(2)
        #     if (findFor(self.udid, 1, "hanhtrang.png", 0)!= 0):
        #         y=True
        # if(y==False):
        #     return False
        sc=screen_capture(self.udid)
        listcanxoa=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]        
        listnull=find2(sc[153:368,496:760],"otrong.png",threshold=0.8)
        listsdo=find2(sc[153:368,496:760],"sachdo.png",threshold=0.7)
        if(listnull!=0):
            listcanxoa = listcanxoa[:-len(listnull)]
        if(listsdo!=0):
            for i in listsdo:
                vtcot=(i[0]+(54.8/2))/54.8
                vtcot=round(vtcot)
                vthang=(i[1]+(52.75/2))/52.75
                vthang=round(vthang)
                o=(vthang - 1) * 4 + vtcot
                if(o in listcanxoa):
                    listcanxoa.remove(o)
        updated_arr = list(map(self.update_value, listcanxoa))
        return (updated_arr)

            
    def findC(self,image,count=5,c=1):
        if(findFor(self.udid,img=image,n=count,yclick=c)!=0):
            return True
        else:
            return False
 
    def bando(self):
        for i in range(5):
            click(self.udid, 116,357,"ban nhanh" )
            time.sleep(1)
            if (findFor(self.udid, 3, "bannhanh.png", 0)!= 0):
                listcx=self.locdo()
                for i in reversed(listcx):
                    click(self.udid, i[0],i[1] )
                    click(self.udid, i[0],i[1] )
                    time.sleep(0.5)
                    click(self.udid, 899, 491,"vienht")
                    click(self.udid, 899, 491,"vienht")
                time.sleep(1)
                click(self.udid, 917, 27,"nutx")
                return True
        return False
            
    def lenbai(self):
        for i in range(5):
            click(self.udid, 856,110 ,"map")
            if (findFor(self.udid, 5, "dichuyen.png", 0)!= 0):
                click(self.udid, 826, 121,"giang tam thon")
                time.sleep(1)
                if (findFor(self.udid, 2, "phongmadong.png", 1)!= 0):
                    click(self.udid, 219, 333,"tdo1")
                    return True
        return False

    def batauto(self):
        click(self.udid,916 ,209 )
        for i in range(5):
            if (findFor(self.udid, 1, "dangbatauto.png", 0)!= 0):
                break
            else:
                click(self.udid, 864, 209)
                time.sleep(1)
        
        
        
    def main(self):
        while True:
            self.loadgame()
            if (findFor(self.udid, 3, "dangnhap.png",1 )!= 0):
                time.sleep(3)
                if (findFor(self.udid, 15, "batdau.png",1 )!= 0):
                    time.sleep(5)
                    findFor(self.udid,5,"roikhoi.png",threshold=0.8)
                    if(self.phu()==True):
                        if(self.chuduocdiem()==True):
                            if(self.bando()==True):
                                if(self.lenbai()==True):
                                    self.dungdi()
                                    swipe(self.udid,83,446,177,396,5000)
                                    time.sleep(5)
                                    self.batauto()
                                    time.sleep(1200)
                                    
                                
                            
                        
                        
a=get_connected_devices()
toolLQ(a[0]).main()