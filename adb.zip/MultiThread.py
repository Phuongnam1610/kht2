from main import *
from PyQt5.QtCore import QThread
from file import *
tools=[]
threads=[]

devices = get_connected_devices()


def Ham(u):
        for i in tools:
            i.terminate()
        # for item in devicessl:
        for i in tools:
            i.u=u
            i.start()

def stoptool():
        for i in tools:
            i.terminate()
def makefile(custom=0):
    filetk=getfile(len(devices),custom)
    for i,v in enumerate(tools[3:]):
    
        v.listtk=filetk[i]

class MyThread(QThread,toolLQ):
    # Tạo một tín hiệu để gửi thông báo từ thread con đến thread chính

    def __init__(self,u,udid,index=0):
        super().__init__(udid=udid)
        self.u=u
        self.index=index

    def run(self):
        if(self.u==2):
            makefile(3)
        else:
            makefile()
        # Thực hiện các tác vụ trong thread con
        if(self.u==1):
            self.main(0)
        elif(self.u==2):
            if(self.index==0):
                self.tabchinh()
            elif(self.index==1):
                self.tabchinh()
            elif(self.index==2):
                self.tabchinh()
            else:
                self.main(1) 
        elif(self.u==3):
            self.main(2)
        elif(self.u==4):
            self.main(3)
        elif(self.u==5):
            self.main(4)
        elif(self.u==6):
             self.main(1)
        elif(self.u==7):
             self.main(2)  
        elif(self.u==8):
             self.main(3)   
        elif(self.u==9):
             self.main(4)    
        elif(self.u==10):
             self.main(5)     



            
for i,v in enumerate(devices):
    a=MyThread(0,v,index=i)
    tools.append(a)